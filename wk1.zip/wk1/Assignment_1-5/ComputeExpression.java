// Assignment 1.5 - Compute Expression
// this program will compute the expression 9.5 x 4.5 - 2.5 x 3 / 45.5 - 3.5 

public class ComputeExpression {

    public static void main(String[] args) {
        // preform the calcutlation
        double calculation = 9.5 * 4.5 - 2.5 * 3 / 45.5 - 3.5;

        // Output the expression
        System.out.println("the Answer for the expression is " + calculation);
    }

}