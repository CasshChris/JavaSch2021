// Assignment 1.1 - Welcome 
// this program will output 3 statement's. "Welcome to Java!", "Welcome to Computer Science", & "Programming is fun"

public class Welcome {
    public static void main(String[] args){
        // Statement 1
        System.out.println("Welcome to Java!");
        System.out.println(); // Blank line
        
        // Statement 2
        System.out.println("Welcome to Computer Science");
        System.out.println(); // Blank line
        
        // Statement 3
        System.out.println("Programming is fun");
        System.out.println(); // Blank line

    }
}